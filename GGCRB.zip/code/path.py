import os
current_dir = os.getcwd()
CIRC_RNA_DATA_PATH = os.path.join(current_dir, 'dataset')
BERT_MODEL_PATH = os.path.join(current_dir, 'bert')
DOC2VEC_MODEL_PATH = os.path.join(current_dir, 'doc2vec', 'Doc2Vec_model')
ROC_PATH = os.path.join(current_dir, 'ROC and AUC')
