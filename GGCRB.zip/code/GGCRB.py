'''
Author: buildgods 15564595518@163.com
Date: 2024-10-28 19:52:50
LastEditors: buildgods 15564595518@163.com
LastEditTime: 2025-04-06 18:36:48
FilePath: \circ-FHN\code\circ-FHN_GCN_vs.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
import logging
from keras.layers import MultiHeadAttention
from sklearn.model_selection import KFold
from sklearn.metrics import roc_curve, roc_auc_score, precision_score, recall_score, f1_score, accuracy_score
from numpy import interp
import matplotlib.pyplot as plt
import random
import time

from spektral.layers import GCNConv, GATConv
from tensorflow.python.keras.callbacks import ReduceLROnPlateau
from tensorflow.python.keras.layers import  AveragePooling1D
from code.Doc2Vec_Encoder import Doc2Vec_Embedding
from code.five import *
from code.path import ROC_PATH
import tensorflow as tf
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.metrics import AUC as AUC_Metric
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.layers import Layer, Input, Conv1D, BatchNormalization, Activation, Concatenate, Dropout
from tensorflow.keras.layers import GlobalAveragePooling1D, Dense, Bidirectional, LSTM
from tensorflow.keras.initializers import GlorotUniform, RandomNormal

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logging.getLogger('tensorflow').setLevel(logging.ERROR)  

np.random.seed(4)
batch_size_increment = 10  
max_batch_size = 1000  
min_batch_size = 10  
nbfilter = 102
hiddensize = 120
initial_batch_size = 50
maxEpochs = 100

def createECNN(embedding_matrix):
    # Input layers
    sequence_input = Input(shape=(101, 56), name='sequence_input')
    sequence = Conv1D(filters=128, kernel_size=3, padding='same')(sequence_input)
    sequence = BatchNormalization(axis=-1)(sequence)
    sequence = Activation('relu')(sequence)

    profile_input = Input(shape=(101,), name='profile_input')
    embedding = tf.keras.layers.Embedding(input_dim=embedding_matrix.shape[0], output_dim=embedding_matrix.shape[1],
                                          weights=[embedding_matrix], trainable=False)(profile_input)
    profile = Conv1D(filters=128, kernel_size=3, padding='same')(embedding)
    profile = BatchNormalization(axis=-1)(profile)
    profile = Activation('relu')(profile)

    struct_input = Input(shape=(101, 101), name='struct_input')
    identity_features = tf.eye(101, dtype=tf.float32) 


    struct_features = GCNConv(128, activation='relu', kernel_initializer=GlorotUniform(seed=42))(
            [identity_features, struct_input])
    struct_features = GATConv(128, activation='relu', kernel_initializer=GlorotUniform(seed=42))(
            [struct_features, struct_input])
    struct_features = GCNConv(128, activation='relu', kernel_initializer=GlorotUniform(seed=42))(
            [struct_features, struct_input])
       

    mergeInput = Concatenate(axis=-1)([sequence, profile, struct_features])
    overallResult = AveragePooling1D(pool_size=5)(mergeInput)
    overallResult = Dropout(0.5)(overallResult)

    overallResult = Bidirectional(LSTM(120, return_sequences=True))(overallResult)

    attention_output = MultiHeadAttention(num_heads=8, key_dim=64)(overallResult, overallResult)
    attention_output = GlobalAveragePooling1D()(attention_output)


    overallResult = Dense(101, activation='relu')(attention_output)
    overallResult = Dropout(0.25)(overallResult)
    ss_output = Dense(2, activation='softmax', name='ss_output')(overallResult)

    return tf.keras.Model(inputs=[sequence_input, profile_input, struct_input], outputs=[ss_output])


def GGCRB(protein, storage, user):
    logging.info(f"处理蛋白质: {protein}")


    Kmer_features = process_sequence_data(protein)
    Embedding, dataY, embedding_matrix = Doc2Vec_Embedding(protein)
    Struct_features = process_struct_data(protein)

    if Struct_features.shape[0] < Kmer_features.shape[0]:
        missing_count = Kmer_features.shape[0] - Struct_features.shape[0]
        zero_structure = np.zeros((missing_count, 101, 101))  
        Struct_features = np.concatenate((Struct_features, zero_structure), axis=0)

    logging.info(
        f"Kmer特征: {Kmer_features.shape}, Doc2Vec嵌入: {Embedding.shape}, 标签: {dataY.shape}, 结构特征: {Struct_features.shape}")

    indexes = np.random.choice(Kmer_features.shape[0], Kmer_features.shape[0], replace=False)
    training_idx, test_idx = indexes[:round(((Kmer_features.shape[0]) / 10) * 8)], indexes[round(
        ((Kmer_features.shape[0]) / 10) * 8):]

    train_sequence, test_sequence = Kmer_features[training_idx], Kmer_features[test_idx]
    train_profile, test_profile = Embedding[training_idx], Embedding[test_idx]
    train_structure, test_structure = Struct_features[training_idx], Struct_features[test_idx]
    train_label, test_label = dataY[training_idx], dataY[test_idx]

    logging.info(
        f"Kmer训练集大小: {train_sequence.shape},Kmer测试集大小: {test_sequence.shape}, Doc2Vec训练集大小: {train_profile.shape},"
        f"Doc2Vec测试集大小: {test_profile.shape}， 标签训练: {train_label.shape},标签测试: {test_label.shape}, "
        f"结构训练大小: {train_structure.shape}，结构测试大小: {test_structure.shape}")

    current_batch_size = initial_batch_size  
    basic_path = os.path.join(storage, user)
    methodName = protein

    tprs, aucs, Accs, precisions, recalls, fscores, time_diffs = [], [], [], [], [], [], []
    kf = KFold(n_splits=5, shuffle=True)

    results = {'fpr_list': [], 'tpr_list': [], 'aucs': []}
    

    for i, (train_index, eval_index) in enumerate(kf.split(train_label)):
        logging.info(f"第 {i + 1} 折训练开始...")
        tf.keras.backend.clear_session()

        train_X1, eval_X1 = train_sequence[train_index], train_sequence[eval_index]
        train_X2, eval_X2 = train_profile[train_index], train_profile[eval_index]
        train_X3, eval_X3 = train_structure[train_index], train_structure[eval_index]
        train_y, eval_y = train_label[train_index], train_label[eval_index]

        [MODEL_PATH, CHECKPOINT_PATH, _, _] = defineExperimentPaths(basic_path, methodName, str(i))
        model = createECNN(embedding_matrix)

        checkpoint_weight = os.path.join(CHECKPOINT_PATH, "weights.best.hdf5")
        if os.path.exists(checkpoint_weight):
            model.load_weights(checkpoint_weight)

        model.compile(optimizer=Adam(learning_rate=0.0005), loss={'ss_output': 'categorical_crossentropy'}, metrics=['accuracy', AUC_Metric()])
        reduce_lr = ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5, 
            patience=5,  
            min_lr=1e-6, 
            verbose=1
        )

        callbacks = [
            EarlyStopping(monitor='val_loss', patience=10, verbose=2, restore_best_weights=True),
            ModelCheckpoint(checkpoint_weight, monitor='val_loss', save_best_only=True, verbose=1),
            reduce_lr
        ]

        T1 = time.time()
        model.fit(
                {'sequence_input': train_X1, 'profile_input': train_X2, 'struct_input': train_X3},
                {'ss_output': train_y},
                epochs=maxEpochs,
                batch_size=current_batch_size,
                callbacks=callbacks,
                validation_data=(
                    {'sequence_input': eval_X1, 'profile_input': eval_X2, 'struct_input': eval_X3},
                    {'ss_output': eval_y}),
                shuffle=True,
                verbose=1
            )
            

        T2 = time.time()
        time_diff = T2 - T1
        time_diffs.append(time_diff)
        logging.info(f"第 {i + 1} 折训练结束，耗时: {time_diff:.4f} 秒")

        model.save(os.path.join(MODEL_PATH, 'model.h5'))

        prediction_result = model.predict(
            {'sequence_input': test_sequence, 'profile_input': test_profile,'struct_input':test_structure})

        ytrue = test_label[:, 1]
        ypred = prediction_result[:, 1]
        y_pred = np.argmax(prediction_result, axis=-1)

        auc = roc_auc_score(ytrue, ypred)
        fpr, tpr, _ = roc_curve(ytrue, ypred)

        
        # 保存 fpr 和 tpr 数据
        results['fpr_list'].append(fpr)
        results['tpr_list'].append(tpr)
        results['aucs'].append(auc)

        tprs.append(interp(np.linspace(0, 1, 100), fpr, tpr))
        aucs.append(auc)

        acc = accuracy_score(ytrue, y_pred)
        precision = precision_score(ytrue, y_pred, zero_division=0)
        recall = recall_score(ytrue, y_pred)
        fscore = f1_score(ytrue, y_pred)

        Accs.append(acc)
        precisions.append(precision)
        recalls.append(recall)
        fscores.append(fscore)
        logging.info(
            f"第 {i + 1} 折结果 - AUC: {auc:.4f}, ACC: {acc:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {fscore:.4f}")
        if auc > 0.8:  
            current_batch_size = min(current_batch_size + batch_size_increment, max_batch_size)
            logging.info(f"AUC较高，增加批量大小至 {current_batch_size}.")
        else:  
            current_batch_size = max(current_batch_size - batch_size_increment, min_batch_size)
            logging.info(f"AUC较低，减少批量大小至 {current_batch_size}.")

    mean_auc = np.mean(aucs)
    mean_acc = np.mean(Accs)
    mean_precision = np.mean(precisions)
    mean_recall = np.mean(recalls)
    mean_fscore = np.mean(fscores)
    mean_time_diff = np.mean(time_diffs)

    logging.info(
        f"{protein} 最终结果 - AUC: {mean_auc:.4f}, ACC: {mean_acc:.4f}, Precision: {mean_precision:.4f}, Recall: {mean_recall:.4f}, F1: {mean_fscore:.4f}, 平均训练时间: {mean_time_diff:.4f}")

    roc_data = np.column_stack((results['fpr_list'][-1], results['tpr_list'][-1]))
    result_dir = ROC_PATH
    os.makedirs(result_dir, exist_ok=True)
    np.savetxt(os.path.join(result_dir, f'{protein}(AUC={mean_auc:.4f}).txt'), roc_data, delimiter='\t')
    plt.plot(np.linspace(0, 1, 100), np.mean(tprs, axis=0), color=(random.random(), random.random(), random.random()),
             lw=1, label=f"{protein}: {mean_auc:.4f}")

    return mean_auc, mean_time_diff


def defineExperimentPaths(basic_path, methodName, experimentID):
    experiment_name = os.path.join(methodName, experimentID)
    MODEL_PATH = os.path.join(basic_path, experiment_name, 'model')
    CHECKPOINT_PATH = os.path.join(basic_path, experiment_name, 'checkpoints')
    RESULT_PATH = os.path.join(basic_path, experiment_name, 'results')
    mk_dir(MODEL_PATH)
    mk_dir(CHECKPOINT_PATH)
    mk_dir(RESULT_PATH)
    return [MODEL_PATH, CHECKPOINT_PATH, None, RESULT_PATH]


def mk_dir(dir):
    if not os.path.exists(dir):
        os.makedirs(dir)


if __name__ == "__main__":
    storage = './result'
    user = 'buildgods'
    # 'TDP43', 'PUM2' TNRC6 不用测
    circRNA_RBPs = ['PUM2']
    for p in circRNA_RBPs:
        tf.keras.backend.clear_session()
        protein = p
        AUC, Time = GGCRB(protein, storage, user)
        print(f"蛋白质: {protein}, 最终 AUC: {AUC:.4f}, 总耗时: {Time:.4f} 秒")
