import numpy as np  
import gensim  
from tensorflow.keras.preprocessing.sequence import pad_sequences  
from tensorflow.keras.utils import to_categorical  
from code.path import DOC2VEC_MODEL_PATH, CIRC_RNA_DATA_PATH 


def Doc2Vec_Embedding(protein):

    model_path = DOC2VEC_MODEL_PATH 
    seqpos_path = f"{CIRC_RNA_DATA_PATH}/{protein}/positive"  
    seqneg_path = f"{CIRC_RNA_DATA_PATH}/{protein}/negative"
    seqpos = read_fasta_file(seqpos_path)  
    seqneg = read_fasta_file(seqneg_path)  

    X, y, embedding_matrix = RNA2Vec(10, 1, 30, model_path, 101, seqpos, seqneg)

    return X, y, embedding_matrix  


def read_fasta_file(fasta_file):
    seq_dict = {}  
    bag_sen = []  
    with open(fasta_file, 'r') as fp: 
        name = ''  
        for line in fp: 
            line = line.rstrip()  
            if line.startswith('>'):  
                name = line[1:]  
                seq_dict[name] = ''  
            else:
                seq_dict[name] += line.upper()  

    for seq in seq_dict.values(): 
        seq = seq.replace('T', 'U')  
        bag_sen.append(seq)  

    return np.asarray(bag_sen)  


def RNA2Vec(k, s, vector_dim, model_path, MAX_LEN, pos_sequences, neg_sequences):

    model = gensim.models.Doc2Vec.load(model_path) 
    pos_list = seq2ngram(pos_sequences, k, s, model.wv)  
    neg_list = seq2ngram(neg_sequences, k, s, model.wv)  
    seqs = pos_list + neg_list  

    X = pad_sequences(seqs, maxlen=MAX_LEN, padding='post')  
    y = np.array([1] * len(pos_list) + [0] * len(neg_list))  
    y = to_categorical(y)  

 
    embedding_matrix = np.zeros((len(model.wv.vocab), vector_dim))
    for i in range(len(model.wv.vocab)):  
        embedding_vector = model.wv[model.wv.index2word[i]]  
        if embedding_vector is not None:  
            embedding_matrix[i] = embedding_vector  
    return X, y, embedding_matrix  


def seq2ngram(seqs, k, s, wv):

    list01 = []  
    for line in seqs:  
        line = line.strip()  
        l = len(line)  
        list2 = []  
        for i in range(0, l, s):  
            if i + k > l:  
                break
            list2.append(line[i:i + k])  
        list01.append(convert_data_to_index(list2, wv))  
    return list01  


def convert_data_to_index(string_data, wv):

    index_data = []  
    for word in string_data: 
        if word in wv.vocab:  
            index_data.append(wv.vocab[word].index)  

    if not index_data: 
        index_data.append(0)  

    return index_data  
